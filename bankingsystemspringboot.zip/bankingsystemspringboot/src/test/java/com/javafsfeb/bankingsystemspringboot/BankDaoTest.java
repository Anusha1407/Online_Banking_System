package com.javafsfeb.bankingsystemspringboot;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.javafsfeb.bankingsystemspringboot.dao.BankDao;
import com.javafsfeb.bankingsystemspringboot.exception.UserExceptions;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BankDaoTest {
	@Autowired
	private BankDao bankDao;

	@Test
	public void testaddUserTest() {
		UserTrackerBean bean = new UserTrackerBean();
		bean.setAccountId(100000);
		bean.setBal(100000);
		bean.setEmail("anuveeranki@gmail.com");
		bean.setMobile(8688441105l);
		bean.setPanCard("SDFGH34567");
		bean.setPassword("Sreerama@1");
		bean.setUserId(10000);
		bean.setUserName("Anusha");
		bean.setUserType("user");
		try {
			boolean check = bankDao.addUser(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(UserExceptions.class, () -> {
				bankDao.addUser(bean);
			});
		}
	}

	@Test
	public void testupdateUserTest() {
		UserTrackerBean bean = new UserTrackerBean();
		bean.setAccountId(100001);
		bean.setPassword("Sreerama@1");
		bean.setEmail("anuveeranki@gmail.com");
		bean.setMobile(8688441105l);
		try {
			boolean check = bankDao.updateUser(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(UserExceptions.class, () -> {
				bankDao.addUser(bean);
			});
		}
	}

	@Test
	public void testcheckBookRequestTest() {
		ServiceTrackingBean bean = new ServiceTrackingBean();
		bean.setAccountId(100001);
		try {
			boolean check = bankDao.checkBookRequest(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(UserExceptions.class, () -> {
				bankDao.checkBookRequest(bean);
			});
		}
	}

	@Test
	public void testgetAllTransactionsTest() {
		Assertions.assertNotNull(bankDao.getAllTransactions(100001));
	}

	@Test
	public void testgetAllTransactionTest() {
		Assertions.assertNotNull(bankDao.getAllTransaction());
	}

	@Test
	public void testgetUserDetailsTest() {
		Assertions.assertNotNull(bankDao.getUserDetails());
	}

	@Test
	public void testgetAllcheckBookRequestTest() {
		Assertions.assertNotNull(bankDao.getAllcheckBookRequest());
	}
}
