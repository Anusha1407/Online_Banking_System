package com.javafsfeb.bankingsystemspringboot.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="service_tracking")
public class ServiceTrackingBean {
	
	@GeneratedValue
	@Id
	@Column(name="Service_Id")
	private int serviceId;
	
//	@Column(name="Service_Description")
//	private String serviceDescription;
	
	@Column(name="Service_Raised_Date")
	private Date serviceRaisedDate;
	
	@Column(name="Account_Id")
	private int accountId;
	
//	@Column(name="Service_Status")
//	private String serviceStatus;

}
