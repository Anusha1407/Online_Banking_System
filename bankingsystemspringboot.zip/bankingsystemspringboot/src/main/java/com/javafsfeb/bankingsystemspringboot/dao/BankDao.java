package com.javafsfeb.bankingsystemspringboot.dao;

import java.util.List;

import com.javafsfeb.bankingsystemspringboot.beans.LoginBean;
import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionDetailsBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;

public interface BankDao {
	public UserTrackerBean login(LoginBean loginBean);

	public boolean addUser(UserTrackerBean userbean);

	public boolean updateUser(UserTrackerBean updateDetail);

	public TransactionDetailsBean doTransaction(TransactionBean transBean);

	public List<TransactionDetailsBean> getAllTransactions(int accountId);
	
	public List<TransactionDetailsBean> getAllTransaction();
	
	public List<UserTrackerBean> getUserDetails();

	public List<ServiceTrackingBean> getAllcheckBookRequest();

	public boolean checkBookRequest(ServiceTrackingBean serviceTrackerBean);

}
