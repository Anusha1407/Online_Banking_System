package com.javafsfeb.bankingsystemspringboot.service;

import java.util.List;

import com.javafsfeb.bankingsystemspringboot.beans.LoginBean;
import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionDetailsBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;

public interface BankService {
	public UserTrackerBean login(LoginBean loginBean);

	public boolean addUser(UserTrackerBean userBean);

	public boolean updateUser(UserTrackerBean updateDetail);

	public TransactionDetailsBean doTransaction(TransactionBean transBean);

	public List<TransactionDetailsBean> getAllTransactions(int accountId);

	public List<TransactionDetailsBean> getAllTransaction();
	
	public List<UserTrackerBean> getUserDetails();
	
	boolean checkBookRequest(ServiceTrackingBean serviceTracker);

	List<ServiceTrackingBean> getAllcheckBookRequest();

}
