package com.javafsfeb.bankingsystemspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javafsfeb.bankingsystemspringboot.beans.LoginBean;
import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionDetailsBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserResponse;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.javafsfeb.bankingsystemspringboot.service.BankService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BankMainController {

	@Autowired
	private BankService service;

	@PostMapping("/login")
	public UserResponse login(@RequestBody LoginBean loginBean, ModelMap modelMap) {
		UserTrackerBean userBean = service.login(loginBean);
		modelMap.addAttribute("userBean", userBean);
		UserResponse userResponse = new UserResponse();

		if (userBean != null) {
			userResponse.setStatusCode(401);
			userResponse.setMessage("You have LoggedIn successfully");
			userResponse.setDescription("User record Found");
			userResponse.setUserTrackerBean(userBean);

		} else {
			userResponse.setStatusCode(402);
			userResponse.setMessage("failed");
			userResponse.setDescription("Please enter valid Password!!");
		}
		return userResponse;

	}// end of login()

	@PostMapping(path = "/addUser")
	public UserResponse addUser(@RequestBody UserTrackerBean customerBean) {
		boolean isAdded = service.addUser(customerBean);

		UserResponse response = new UserResponse();
		if (isAdded) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("User Successfully Added");
		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Unable to add User");
		}
		return response;

	}// end of addUser()

	@PutMapping(path = "/updateUser")
	public UserResponse updateUser(@RequestBody UserTrackerBean updateDetail) {

		boolean isUpdated = service.updateUser(updateDetail);
		UserResponse response = new UserResponse();
		if (isUpdated) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("User Successfully Updated");
		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Unable to update User");
		}
		return response;

	}

	@PostMapping(path = "/transaction")
	public UserResponse doTansaction(@RequestBody TransactionBean transBean, ModelMap modelMap) {
		TransactionDetailsBean isTransfered = service.doTransaction(transBean);
		modelMap.addAttribute("isTransfered", isTransfered);
		UserResponse response = new UserResponse();
		if (isTransfered != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Transction successfull");
			response.setTBean(isTransfered);

		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Something went wrong, please try again!!");
		}
		return response;
	}// end of transaction()

	@GetMapping(path = "/getAllTransactions")
	public List<TransactionDetailsBean> getAlltransactions(@RequestParam("accountId") int accountId) {
		List<TransactionDetailsBean> tranBean = service.getAllTransactions(accountId);
		UserResponse response = new UserResponse();

		if (tranBean != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Your Transaction Details");
			response.setTransBean(tranBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("Fail");
			response.setDescription("Sorry no transaction is found for user!! ");
		}

		return tranBean;
	}// end of getAlltransactions

	@GetMapping(path = "/getAllTransaction")
	public UserResponse getAlltransaction() {
		List<TransactionDetailsBean> tranBean = service.getAllTransaction();
		UserResponse response = new UserResponse();
		if (tranBean != null) {
			response.setStatusCode(401);
			response.setMessage("success");
			response.setTransBean(tranBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("no request available");
		}
		return response;
	}// end of getAlltransaction

	@GetMapping(path = "/getUserDetails")
	public UserResponse getUserDetails() {
		List<UserTrackerBean> userTrackerBean = service.getUserDetails();
		UserResponse response = new UserResponse();
		if (userTrackerBean != null) {
			response.setStatusCode(401);
			response.setMessage("success");
			response.setUsers(userTrackerBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("no users available");
		}
		return response;
	}// end of getUserDetails
	
	
	
	@PostMapping(path = "/checkBookRequest")
	public UserResponse checkBookRequest(@RequestBody ServiceTrackingBean serviceTracker) {
		boolean isAdded = service.checkBookRequest(serviceTracker);
		UserResponse response = new UserResponse();
		if (isAdded) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Check book request accepted");

		} else {
			response.setStatusCode(402);
			response.setMessage("failed");
			response.setDescription("Something went wrong");
		}
		return response;

	}// end of checkBookRequest

	@GetMapping(path = "/getAllCheckBookRequest")
	public UserResponse getAllCheckBookRequest() {

		List<ServiceTrackingBean> requestList = service.getAllcheckBookRequest();
		UserResponse response = new UserResponse();
		if (requestList != null) {
			response.setStatusCode(401);
			response.setMessage("success");
			response.setCheckBookList(requestList);

		} else {
			{
				response.setStatusCode(402);
				response.setMessage("no request available");
			}

		}
		return response;

	}// end of getAllchequeBookList
}
