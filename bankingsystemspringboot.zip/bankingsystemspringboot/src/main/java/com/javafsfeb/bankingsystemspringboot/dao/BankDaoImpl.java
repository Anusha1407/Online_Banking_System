package com.javafsfeb.bankingsystemspringboot.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

//import com.javafsfeb.bankingsystemspringboot.beans.FundTransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.LoginBean;
import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionDetailsBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.javafsfeb.bankingsystemspringboot.exception.UserExceptions;

@Repository
public class BankDaoImpl implements BankDao {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public UserTrackerBean login(LoginBean loginBean) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserTrackerBean where userId =:userid and password =:pwd";
		Query query = manager.createQuery(jpql);
		query.setParameter("userid", loginBean.getUserId());
		query.setParameter("pwd", loginBean.getLoginPassword());
		UserTrackerBean userBean = null;
		try {
			userBean = (UserTrackerBean) query.getSingleResult();
			if ((userBean.getPassword()).equals(loginBean.getLoginPassword())) {
				return userBean;
			}
		} catch (Exception e) {
			throw new UserExceptions("Please enter valid UserId!!");
		}
		manager.close();
		return null;
	}

	@Override
	public boolean addUser(UserTrackerBean customerbean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction ts = manager.getTransaction();
		boolean isAdded = false;
		try {
			ts.begin();
			manager.persist(customerbean);
			isAdded = true;
			ts.commit();
		} catch (Exception e) {
			throw new UserExceptions("UserId Already Exist");
		}
		manager.close();
		return isAdded;
	}// end of addUser()

	@Override
	public boolean updateUser(UserTrackerBean updateDetail) {
		EntityManager manager = emf.createEntityManager();
		UserTrackerBean userBean = manager.find(UserTrackerBean.class, updateDetail.getAccountId());
		boolean isUpdated = false;
		if (userBean != null) {

			try {
				EntityTransaction trans = manager.getTransaction();
				trans.begin();
				String email = updateDetail.getEmail();
				if (email != null) {
					userBean.setEmail(email);
				}
				long mobile = updateDetail.getMobile();
				if (mobile != 0) {
					userBean.setMobile(mobile);
				}
				String pass = updateDetail.getPassword();
				if (pass != null) {
					userBean.setPassword(pass);
				}

				manager.persist(userBean);
				isUpdated = true;
				trans.commit();

			} catch (Exception e) {
//				e.printStackTrace();
				throw new UserExceptions("UserId Not Found");
			}
			manager.close();
		}

		return isUpdated;
	}// end of updateUser()

	@Override
	public TransactionDetailsBean doTransaction(@RequestBody TransactionBean transBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction trans = null;
		TransactionDetailsBean bean = new TransactionDetailsBean();
		UserTrackerBean bean1 = manager.find(UserTrackerBean.class, transBean.getFromAccountId());
		UserTrackerBean bean2 = manager.find(UserTrackerBean.class, transBean.getToAccountId());
		if (bean1 != null && bean2 != null) {
			if (bean1.getBal() > transBean.getAmount()) {
				bean1.setBal(bean1.getBal() - transBean.getAmount());
				bean2.setBal(bean2.getBal() + transBean.getAmount());

				try {
					bean.setAccountId(bean1.getAccountId());
					bean.setDateOfTransaction(new Date());
					bean.setTranAmount(transBean.getAmount());
					bean.setBeneficiaryAccountId(bean2.getAccountId());
					bean.setTransactionType("Online Mode");
					bean.setTranDescription("Transfer Amount");

					trans = manager.getTransaction();
					trans.begin();
					manager.persist(bean);
					trans.commit();
				} catch (Exception e) {
					throw new UserExceptions("Check the Details and Send Again!!");
				}
				manager.close();
			} else {
				throw new UserExceptions("You dont have enough amount to transfer");
			}
		} else {
			throw new UserExceptions("Enter valid Details and Send Again!!");
		}

		return bean;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionDetailsBean> getAllTransactions(int accountId) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from TransactionDetailsBean where accountId=:accountid";
		Query query = manager.createQuery(jpql);
		query.setParameter("accountid", accountId);

		List<TransactionDetailsBean> transList = null;
		try {
			transList = (List<TransactionDetailsBean>) query.getResultList();
		} catch (Exception e) {
//			e.printStackTrace();
			throw new UserExceptions("User Id Not Found!!");
		}
		return transList;
	}

	@Override
	public boolean checkBookRequest(ServiceTrackingBean serviceTrackerBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction ts = manager.getTransaction();
		String jpql = "from UserTrackerBean where accountId=:id";
		Query query = manager.createQuery(jpql);
		query.setParameter("id", serviceTrackerBean.getAccountId());

		boolean isAdded = false;
		try {
			@SuppressWarnings("unused")
			UserTrackerBean bean = new UserTrackerBean();
			bean = (UserTrackerBean) query.getSingleResult();
			ts.begin();

			serviceTrackerBean.setServiceRaisedDate(new Date());

			manager.persist(serviceTrackerBean);
			isAdded = true;
			ts.commit();

		} catch (Exception e) {
			throw new UserExceptions("Enter Valid Id");
		}
		manager.close();
		return isAdded;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServiceTrackingBean> getAllcheckBookRequest() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from ServiceTrackingBean";
		Query query = manager.createQuery(jpql);
		List<ServiceTrackingBean> checkBookList = null;
		try {
			checkBookList = query.getResultList();
		} catch (Exception e) {
//			e.printStackTrace();
			throw new UserExceptions("No Data Found!!");
		}

		return checkBookList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionDetailsBean> getAllTransaction() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from TransactionDetailsBean";
		Query query = manager.createQuery(jpql);

		List<TransactionDetailsBean> transList = null;
		try {
			transList = query.getResultList();
		} catch (Exception e) {
//			e.printStackTrace();
			throw new UserExceptions("No Data Found!!");
		}

		return transList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserTrackerBean> getUserDetails() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserTrackerBean where userType=:type";
		Query query = manager.createQuery(jpql);

		query.setParameter("type", "user");
		List<UserTrackerBean> userList = null;
		try {
			userList = query.getResultList();
		} catch (Exception e) {
//			e.printStackTrace();
			throw new UserExceptions("No Data Found!!");
		}
		return userList;
	}
}
