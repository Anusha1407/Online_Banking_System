package com.javafsfeb.bankingsystemspringboot.beans;

import java.util.List;

import lombok.Data;

@Data
public class UserResponse {
	private int statusCode;
	private String message;
	private String description;
	private UserTrackerBean userTrackerBean;
	private List<TransactionDetailsBean> transBean;
	private List<UserTrackerBean> users;
	private TransactionDetailsBean tBean;
	private List<ServiceTrackingBean> checkBookList;

}
