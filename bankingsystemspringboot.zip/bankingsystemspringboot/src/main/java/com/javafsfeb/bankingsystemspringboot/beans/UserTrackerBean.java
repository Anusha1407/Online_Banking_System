package com.javafsfeb.bankingsystemspringboot.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "user_tracker")
public class UserTrackerBean {

	@Id
	@Column(name = "Account_Id")
	private int accountId;

	@Column(name = "User_Id")
	private int userId;

	@Column(name = "Login_Password")
	private String password;

	@Column(name="User_Name")
	private  String userName;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Pan_Card")
	private String panCard;
	
	@Column(name = "User_Type")
	private String userType;
	
	@Column(name = "Moblie_Num")
	private long mobile;
	
	@Column(name="Balance")
	private double bal;

}
