package com.javafsfeb.bankingsystemspringboot.beans;

import lombok.Data;

@Data
public class LoginBean {

	private int userId;

	private String loginPassword;
}
