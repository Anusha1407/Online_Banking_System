package com.javafsfeb.bankingsystemspringboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;

@Configuration
public class UserConfig {

	@Bean
	public LocalEntityManagerFactoryBean getEntity() {
		LocalEntityManagerFactoryBean entityFactoryBean = new LocalEntityManagerFactoryBean();
		entityFactoryBean.setPersistenceUnitName("bankingSystem");
		return entityFactoryBean;

	}
}
