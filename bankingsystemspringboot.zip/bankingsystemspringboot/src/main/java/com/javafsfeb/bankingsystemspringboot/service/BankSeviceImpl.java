package com.javafsfeb.bankingsystemspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javafsfeb.bankingsystemspringboot.beans.LoginBean;
import com.javafsfeb.bankingsystemspringboot.beans.ServiceTrackingBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.javafsfeb.bankingsystemspringboot.beans.TransactionDetailsBean;
import com.javafsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.javafsfeb.bankingsystemspringboot.dao.BankDao;
import com.javafsfeb.bankingsystemspringboot.exception.UserExceptions;

@Service
public class BankSeviceImpl implements BankService {
	@Autowired
	private BankDao dao;

	@Override
	public UserTrackerBean login(LoginBean loginBean) {
		if (loginBean.getUserId() != 0) {
			if (loginBean.getLoginPassword() != null) {
				return dao.login(loginBean);
			} else {
				throw new UserExceptions("Enter Password also!!");
			}
		} else {
			throw new UserExceptions("Enter Details First!!");
		}
//		return null;
	}

	@Override
	public boolean addUser(UserTrackerBean userBean) {
		return dao.addUser(userBean);
	}

	@Override
	public boolean updateUser(UserTrackerBean updateDetail) {
		return dao.updateUser(updateDetail);
	}

	@Override
	public TransactionDetailsBean doTransaction(TransactionBean transBean) {
		return dao.doTransaction(transBean);
	}

	@Override
	public List<TransactionDetailsBean> getAllTransactions(int accountId) {
		return dao.getAllTransactions(accountId);
	}

	@Override
	public boolean checkBookRequest(ServiceTrackingBean serviceTracker) {
		return dao.checkBookRequest(serviceTracker);
	}

	@Override
	public List<ServiceTrackingBean> getAllcheckBookRequest() {
		return dao.getAllcheckBookRequest();
	}

	@Override
	public List<TransactionDetailsBean> getAllTransaction() {
		return dao.getAllTransaction();
	}

	@Override
	public List<UserTrackerBean> getUserDetails() {
		return dao.getUserDetails();
	}

}
