package com.javafsfeb.bankingsystemspringboot.beans;

import lombok.Data;

@Data
public class TransactionBean {

	// data member
	private int fromAccountId;
	private int toAccountId;
	private double amount;
	private String transType;

}
