package com.javafsfeb.bankingsystemspringboot.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.javafsfeb.bankingsystemspringboot.beans.UserResponse;
import com.javafsfeb.bankingsystemspringboot.exception.UserExceptions;

@RestControllerAdvice
public class BankMainControllerAdvice {

	@ExceptionHandler(UserExceptions.class)
	public UserResponse handleUserExceptions(UserExceptions userException) {
		UserResponse userResponse =new UserResponse();
		userResponse.setStatusCode(402);
		userResponse.setDescription(userException.getMessage());
		return userResponse;
	}
	
	@ExceptionHandler(Exception.class)
	public UserResponse handleException(Exception e) {
		UserResponse userResponse =new UserResponse();
		userResponse.setStatusCode(402);
		userResponse.setDescription(e.getMessage());
		return userResponse;
	}
}
