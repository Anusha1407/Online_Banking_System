import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { MiniStatement } from 'src/app/mini-statement/mini-statement';
import { User } from 'src/app/new-account';

@Injectable({
  providedIn: 'root'
})
export class UserLoginService {

  constructor(private http: HttpClient) { }
  // tslint:disable-next-line: member-ordering
  users: User[] = [];
  // tslint:disable-next-line: member-ordering
  ministatements: MiniStatement[] = [];

  backendURL = 'http://localhost:8087';
  createUser(users: User) {
    throw new Error('Method not implemented.');
  }

  isLoggedIn() {
    const userDetails = JSON.parse(localStorage.getItem('user'));
    if (userDetails) {
      return true;
    } else {
      return false;
    }
  }

  login(data) {
       return this.http.post<any>(`${this.backendURL}/login` , data);
  }

  getMinistatement(data){
    return this.http.get<any>(`${this.backendURL}/getAllTransactions?accountId=${data.accountId}`);
  }

  getDetailedstatement() {
    return this.http.get<any>(`${this.backendURL}/getAllTransaction`);
  }

  getUserDetails() {
    return this.http.get<any>(`${this.backendURL}/getUserDetails`);
  }

  checkBookRequest(data) {
    return this.http.post<any>(`${this.backendURL}/checkBookRequest`, data);
  }

  getCheckBookRequest() {
    return this.http.get<any>(`${this.backendURL}/getAllCheckBookRequest`);
  }

  addUser(users) {
    return this.http.post<any>(`${this.backendURL}/addUser`, users);
  }

  transferFund(data) {
    return this.http.post<any>(`${this.backendURL}/transaction`, data);
  }

  updateEmail(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser`, data);
  }

  updateMobile(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser` , data);
  }

  changePassword(data) {
    return this.http.put<any>(`${this.backendURL}/updateUser` , data);
  }

}
