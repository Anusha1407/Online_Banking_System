import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { NgForm} from "@angular/forms";
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
// import { StatementComponent } from './statement/statement.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { DetailedStatementComponent } from './detailed-statement/detailed-statement.component';
import { FooterComponent } from './footer/footer.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ForgotPasswordComponent } from './updateDetails/forgot-password/forgot-password.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { LoginComponent } from './login/login.component';
import { UpdateMobileComponent } from './updateDetails/update-mobile/update-mobile.component';
import { UpdateAddressComponent } from './updateDetails/update-address/update-address.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { CheckbookRequestComponent } from './checkbook-request/checkbook-request.component';
import { GetcheckbookDetailsComponent } from './getcheckbook-details/getcheckbook-details.component';
import { ContactComponent } from './contact/contact.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    // StatementComponent,
    MiniStatementComponent,
    DetailedStatementComponent,
    FooterComponent,
    NewAccountComponent,
    PageNotFoundComponent,
    ForgotPasswordComponent,
    FundTransferComponent,
    LoginComponent,
    UpdateMobileComponent,
    UpdateAddressComponent,
    UserDetailsComponent,
    CheckbookRequestComponent,
    GetcheckbookDetailsComponent,
    ContactComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
