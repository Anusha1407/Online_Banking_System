import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { DetailedStatement } from './detailed-statement';

@Component({
  selector: 'app-detailed-statement',
  templateUrl: './detailed-statement.component.html',
  styleUrls: ['./detailed-statement.component.css']
})
export class DetailedStatementComponent implements OnInit {


  detailedstatements: DetailedStatement[];

  constructor(private service: UserLoginService) {
    this.service.getDetailedstatement();
  }
  ngOnInit() {
    this.service.getDetailedstatement().subscribe(data => {
      this.detailedstatements = data.transBean;
    })
  };

}
