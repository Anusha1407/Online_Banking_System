export class DetailedStatement {
    constructor(
       public accountId : number,
        public transactionType: string,
        public transactionId : number,
        public dateOfTransaction: Date,
        public tranAmount :number,
        public tranDescription:string
    ){}
}


