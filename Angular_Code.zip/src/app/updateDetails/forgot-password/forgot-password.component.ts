import { Component, OnInit } from '@angular/core';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  changePassword(form: NgForm) {
    console.log(form.value);
    this.service.changePassword(form.value).subscribe(response => {
      console.log(response);
      if (response.statusCode === 402) {
        this.error = response.description;
        setTimeout(()=>{
          this.error=null;
        },5000);
      } else {
        this.description = response.description;
        setTimeout(()=>{
          this.description=null;
        },5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

}
