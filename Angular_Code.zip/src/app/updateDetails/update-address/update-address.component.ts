import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';

@Component({
  selector: 'app-update-address',
  templateUrl: './update-address.component.html',
  styleUrls: ['./update-address.component.css']
})
export class UpdateAddressComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }

  ngOnInit() {
  }
  updateEmail(form: NgForm) {
    console.log(form.value);
    this.service.updateEmail(form.value).subscribe(response => {
      console.log(response);
      if (response.statusCode === 402) {
        this.error = response.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = response.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }
}
