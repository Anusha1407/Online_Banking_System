import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from 'src/app/_services/user-login/user-login.service';

@Component({
  selector: 'app-update-mobile',
  templateUrl: './update-mobile.component.html',
  styleUrls: ['./update-mobile.component.css']
})
export class UpdateMobileComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService)  { }

  ngOnInit() {

  }
  updateMobile(form: NgForm) {
    this.service.updateMobile(form.value).subscribe(data => {
      console.log(data);
      if (data.statusCode === 402) {
        this.error = data.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = data.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }


}
