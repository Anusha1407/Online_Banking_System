import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
// import { StatementComponent } from './statement/statement.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { DetailedStatementComponent } from './detailed-statement/detailed-statement.component';

import { NewAccountComponent } from './new-account/new-account.component';
import { ForgotPasswordComponent } from './updateDetails/forgot-password/forgot-password.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { LoginComponent } from './login/login.component';
import { UpdateMobileComponent } from './updateDetails/update-mobile/update-mobile.component';
import { UpdateAddressComponent } from './updateDetails/update-address/update-address.component';
import { AuthGuard } from './auth.guard';
import { UserDetailsComponent } from './user-details/user-details.component';
import { GetcheckbookDetailsComponent } from './getcheckbook-details/getcheckbook-details.component';
import { CheckbookRequestComponent } from './checkbook-request/checkbook-request.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ContactComponent } from './contact/contact.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  // { path: 'statement', component: StatementComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin', 'user'] } },
  { path: 'mini-statement', component: MiniStatementComponent, canActivate: [AuthGuard], data: { expectedRole: ['user'] } },
  { path: 'detailed-statement', component: DetailedStatementComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin'] } },
  { path: 'user-details', component: UserDetailsComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin'] } },
  { path: 'login', component: LoginComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'new-account', component: NewAccountComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin'] } },
  { path: 'view-checkbooks', component: GetcheckbookDetailsComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin'] } },
  { path: 'request-checkbook', component: CheckbookRequestComponent, canActivate: [AuthGuard], data: { expectedRole: ['user'] } },
  { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [AuthGuard], data: { expectedRole: ['Admin', 'user'] } },
  { path: 'fund-transfer', component: FundTransferComponent, canActivate: [AuthGuard], data: { expectedRole: ['user'] } },
  { path: 'update-mobile', component: UpdateMobileComponent, canActivate: [AuthGuard], data: { expectedRole: ['user'] } },
  { path: 'update-address', component: UpdateAddressComponent, canActivate: [AuthGuard], data: { expectedRole: ['user'] } },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
