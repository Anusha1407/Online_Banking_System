import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { User } from '../new-account';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html',
  styleUrls: ['./new-account.component.css']
})
export class NewAccountComponent implements OnInit {

  description: string;
  error: string;
  constructor(private service: UserLoginService) { }
  
  submitForm(form: NgForm) {
    console.log(form.value);
    this.service.addUser(form.value).subscribe(response => {
      console.log(response);
      if (response.statusCode === 402) {
        this.error = response.description;
        setTimeout(()=>{
          this.error=null;
        },5000);
      } else {
        this.description = response.description;
        setTimeout(()=>{
          this.description=null;
        },5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {

  }

}
