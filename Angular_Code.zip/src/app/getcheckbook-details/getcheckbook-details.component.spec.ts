import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcheckbookDetailsComponent } from './getcheckbook-details.component';

describe('GetcheckbookDetailsComponent', () => {
  let component: GetcheckbookDetailsComponent;
  let fixture: ComponentFixture<GetcheckbookDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetcheckbookDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetcheckbookDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
