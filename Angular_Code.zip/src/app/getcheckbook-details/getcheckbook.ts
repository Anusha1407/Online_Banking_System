export class checkbookDetails {
    constructor(
       public accountId : number,
        public serviceId: number,
        public serviceRaisedDate : Date
    ){}
}