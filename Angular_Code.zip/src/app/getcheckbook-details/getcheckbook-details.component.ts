import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { checkbookDetails } from './getcheckbook';

@Component({
  selector: 'app-getcheckbook-details',
  templateUrl: './getcheckbook-details.component.html',
  styleUrls: ['./getcheckbook-details.component.css']
})
export class GetcheckbookDetailsComponent implements OnInit {

  details: checkbookDetails[];

  constructor(private service: UserLoginService) {
    this.service.getCheckBookRequest();
  }
  ngOnInit() {
    this.service.getCheckBookRequest().subscribe(data => {
      this.details = data.checkBookList;
    })
  };

}
