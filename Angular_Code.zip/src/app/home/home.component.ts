import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }
  send(form:NgForm) {
    console.log(form.value);
    alert('Message send successful, You will get the response soon!!!');
    form.reset();
  }
  ngOnInit() {
  }

}
