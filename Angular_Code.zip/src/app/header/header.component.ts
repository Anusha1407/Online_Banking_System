import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, DoCheck {

  role = 'null';

  constructor(private router: Router) { }

  ngOnInit() {
  }

  logout() {
    this.role = 'null';
    localStorage.clear();
    this.router.navigateByUrl('/login');
  }
  ngDoCheck(): void {
    let userDetails = JSON.parse(localStorage.getItem('user'));
    if(userDetails) {
      this.role = userDetails.userTrackerBean.userType;
    }
  }

}
