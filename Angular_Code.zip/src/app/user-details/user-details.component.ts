import { Component, OnInit } from '@angular/core';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { UserDetails } from './user-details';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  userdetails: UserDetails[];

  constructor(private service: UserLoginService) {
    this.service.getUserDetails();
  }
  ngOnInit() {
    this.service.getUserDetails().subscribe(data => {
      this.userdetails = data.users;
    })
  };

}
