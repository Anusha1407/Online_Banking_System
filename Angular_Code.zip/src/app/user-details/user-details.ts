export class UserDetails {
    constructor(
       public accountId : number,
        public userName: string,
        public mobile : number,
        public panCard: string,
        public bal :number,
        public email:string
    ){}
}