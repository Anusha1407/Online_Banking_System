import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckbookRequestComponent } from './checkbook-request.component';

describe('CheckbookRequestComponent', () => {
  let component: CheckbookRequestComponent;
  let fixture: ComponentFixture<CheckbookRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckbookRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckbookRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
