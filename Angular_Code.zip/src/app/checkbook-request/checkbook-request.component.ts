import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from '../_services/user-login/user-login.service';

@Component({
  selector: 'app-checkbook-request',
  templateUrl: './checkbook-request.component.html',
  styleUrls: ['./checkbook-request.component.css']
})
export class CheckbookRequestComponent implements OnInit {

  
  description: string;
  error: string;
  constructor(private service: UserLoginService) { }
  checkBook(form: NgForm) {
    console.log(form.value);
    this.service.checkBookRequest(form.value).subscribe(response => {
      console.log(response);
      if (response.statusCode === 402) {
        this.error = response.description;
        setTimeout(() => {
          this.error = null;
        }, 5000);
      } else {
        this.description = response.description;
        setTimeout(() => {
          this.description = null;
        }, 5000);
      }
      form.reset();
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
