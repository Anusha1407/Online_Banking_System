import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UserLoginService } from './_services/user-login/user-login.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private admin : UserLoginService) {}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
      const expectedRoleArray = next.data.expectedRole;
      const userDetails = JSON.parse(localStorage.getItem('user'));
      let expectedRole = '';
      for(const index in expectedRoleArray ) {
        if(userDetails && expectedRoleArray[index] === userDetails.userTrackerBean.userType) {
            expectedRole = expectedRoleArray[index];
        }
      }
      if(userDetails && this.admin.isLoggedIn() && userDetails.userTrackerBean.userType === expectedRole) {
        console.log('user athenticated');
        return true;
      } else {
        console.log('user not athenticated');
        return false;
      }
  }
  
}
