import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserLoginService } from '../_services/user-login/user-login.service';
import { MiniStatement } from './mini-statement';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  ministatements:MiniStatement[];
  
  description: string;
  error: string;
  constructor(private service : UserLoginService) { }

  msg:boolean;
   getMinistatement(form: NgForm) {
    console.log(form.value);
    this.service.getMinistatement(form.value).subscribe(response => {
      console.log(response);
      this.ministatements = response;
      this.msg=true;
    }, err => {
      console.log(err);
    });
  }
   ngOnInit() {
  
  };

}
